package livesession.snake.provider;

public class SimpleGameLoop implements GameLoop {
  private static final org.slf4j.Logger logger =
      org.slf4j.LoggerFactory.getLogger(SimpleGameLoop.class);

  public SimpleGameLoop(final SimpleSnakeService simpleSnakeService, final int velocityInMilliseconds) {
  }

  @Override
  public void run() {
    
  }

  @Override
  public void pauseGame() {

  }

  @Override
  public void resumeGame() {

  }

  @Override
  public void stopGame() {

  }
}
